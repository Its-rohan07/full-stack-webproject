<?php
// app/controllers/AiController.php
// Smart Help Assistant — keyword-based FAQ search
// AI Option 1: curated knowledge base with keyword matching
// AI Safety: no personal data processed, admin curates all content, human review on all answers

class AiController {

    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * POST /api/help
     * Accepts JSON: { "query": "how do I return?" }
     * Returns JSON: { "results": [...], "disclaimer": "..." }
     */
    public function search(): void {
        header('Content-Type: application/json');

        // Only accept POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['error' => 'Method not allowed']); exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $query = trim(filter_var($input['query'] ?? '', FILTER_SANITIZE_SPECIAL_CHARS));

        if (strlen($query) < 2) {
            echo json_encode(['results' => [], 'message' => 'Please enter a question.']); exit;
        }

        $results = $this->findMatches($query);

        // Log what the AI suggested (required by AI governance)
        $this->logAiQuery($query, count($results));

        echo json_encode([
            'results'    => $results,
            'disclaimer' => 'This response is AI-assisted and based on our FAQ knowledge base. For critical queries, please contact support@shopease.com.',
            'query'      => htmlspecialchars($query),
        ]);
    }

    /**
     * Keyword matching against faq_kb table.
     * Scores each FAQ by how many query words appear in question + keywords + answer.
     * Returns top 3 matches above a minimum score.
     */
    private function findMatches(string $query): array {
        $faqs = $this->db->query("SELECT * FROM faq_kb")->fetchAll();

        // Tokenise query — strip common stop words
        $stopWords = ['i', 'do', 'how', 'what', 'can', 'my', 'is', 'the', 'a', 'an', 'to', 'in', 'of', 'and', 'or'];
        $queryWords = array_filter(
            explode(' ', strtolower(preg_replace('/[^a-z0-9 ]/i', '', $query))),
            fn($w) => strlen($w) > 1 && !in_array($w, $stopWords)
        );

        if (empty($queryWords)) {
            // Fall back to full query if all words were stop words
            $queryWords = [strtolower($query)];
        }

        $scored = [];

        foreach ($faqs as $faq) {
            $score = 0;
            $haystack = strtolower(
                $faq['question'] . ' ' . $faq['keywords'] . ' ' . $faq['answer'] . ' ' . $faq['category']
            );

            foreach ($queryWords as $word) {
                if (str_contains($haystack, $word)) {
                    // Higher weight for question/keyword match vs answer body
                    $questionHay = strtolower($faq['question'] . ' ' . $faq['keywords']);
                    $score += str_contains($questionHay, $word) ? 3 : 1;
                }
            }

            if ($score > 0) {
                $scored[] = [
                    'faq_id'   => $faq['faq_id'],
                    'question' => htmlspecialchars($faq['question']),
                    'answer'   => htmlspecialchars($faq['answer']),
                    'category' => htmlspecialchars($faq['category']),
                    'score'    => $score,
                ];
            }
        }

        // Sort by score descending, return top 3
        usort($scored, fn($a, $b) => $b['score'] - $a['score']);
        return array_slice($scored, 0, 3);
    }

    private function logAiQuery(string $query, int $resultCount): void {
        $stmt = $this->db->prepare(
            "INSERT INTO activity_log (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)"
        );
        $stmt->execute([
            $_SESSION['user_id'] ?? null,
            'ai_help_query',
            'faq_kb',
            0,
            "Query: \"$query\" | Results returned: $resultCount"
        ]);
    }
}
