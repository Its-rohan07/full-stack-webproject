<?php
// app/controllers/AuthController.php
// Handles login, register, logout

class AuthController {

    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function showLogin(): void {
        require 'app/views/auth/login.php';
    }

    public function showRegister(): void {
        require 'app/views/auth/register.php';
    }

    public function login(): void {
        // Validate CSRF
        $this->validateCsrf();

        $email    = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';

        // Server-side validation
        $errors = [];
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }
        if (empty($password)) {
            $errors[] = 'Password is required.';
        }

        if ($errors) {
            $_SESSION['errors'] = $errors;
            header('Location: /shopease/login');
            exit;
        }

        // Lookup user
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            // Regenerate session ID on login (session fixation protection)
            session_regenerate_id(true);
            $_SESSION['user_id']   = $user['user_id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];

            $this->logActivity($user['user_id'], 'login', 'users', $user['user_id'], 'User logged in');

            $redirect = $user['role'] === 'admin' ? '/shopease/admin' : '/shopease/products';
            header("Location: $redirect");
            exit;
        }

        $_SESSION['errors'] = ['Invalid email or password.'];
        header('Location: /shopease/login');
        exit;
    }

    public function register(): void {
        $this->validateCsrf();

        $name     = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
        $email    = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        $errors = [];
        if (empty($name) || strlen($name) < 2) {
            $errors[] = 'Name must be at least 2 characters.';
        }
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }
        if (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        }
        if ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        }

        if ($errors) {
            $_SESSION['errors'] = $errors;
            header('Location: /shopease/register');
            exit;
        }

        // Check duplicate email
        $stmt = $this->db->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $_SESSION['errors'] = ['An account with this email already exists.'];
            header('Location: /shopease/register');
            exit;
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->db->prepare(
            "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'customer')"
        );
        $stmt->execute([$name, $email, $hash]);
        $newId = $this->db->lastInsertId();

        session_regenerate_id(true);
        $_SESSION['user_id']   = $newId;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_role'] = 'customer';

        $this->logActivity($newId, 'register', 'users', $newId, 'New customer registered');

        $_SESSION['success'] = 'Account created successfully. Welcome!';
        header('Location: /shopease/products');
        exit;
    }

    public function logout(): void {
        if (isset($_SESSION['user_id'])) {
            $this->logActivity($_SESSION['user_id'], 'logout', 'users', $_SESSION['user_id'], 'User logged out');
        }
        session_destroy();
        header('Location: /shopease/login');
        exit;
    }

    // ── Helpers ──────────────────────────────────────────────

    public static function requireLogin(): void {
        if (empty($_SESSION['user_id'])) {
            $_SESSION['errors'] = ['You must be logged in to access this page.'];
            header('Location: /shopease/login');
            exit;
        }
    }

    public static function requireAdmin(): void {
        self::requireLogin();
        if ($_SESSION['user_role'] !== 'admin') {
            http_response_code(403);
            require 'app/views/403.php';
            exit;
        }
    }

    private function validateCsrf(): void {
        $token = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            http_response_code(403);
            die('Invalid CSRF token.');
        }
    }

    public static function generateCsrf(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    private function logActivity(int $userId, string $action, string $entity, int $entityId, string $details): void {
        $stmt = $this->db->prepare(
            "INSERT INTO activity_log (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)"
        );
        $stmt->execute([$userId, $action, $entity, $entityId, $details]);
    }
}
