<?php
// app/controllers/OrderController.php
// CRUD for Orders — place, view, cancel, update status (admin)

class OrderController {

    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    // LIST orders (admin sees all, customer sees own)
    public function index(): void {
        AuthController::requireLogin();
        $isAdmin = $_SESSION['user_role'] === 'admin';

        if ($isAdmin) {
            $stmt = $this->db->prepare(
                "SELECT o.*, u.name AS customer_name, u.email
                 FROM orders o
                 JOIN users u ON o.user_id = u.user_id
                 ORDER BY o.created_at DESC"
            );
            $stmt->execute();
        } else {
            $stmt = $this->db->prepare(
                "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC"
            );
            $stmt->execute([$_SESSION['user_id']]);
        }
        $orders = $stmt->fetchAll();
        require 'app/views/orders/index.php';
    }

    // SHOW single order + items
    public function show(int $id): void {
        AuthController::requireLogin();
        $stmt = $this->db->prepare("SELECT o.*, u.name AS customer_name FROM orders o JOIN users u ON o.user_id=u.user_id WHERE o.order_id=?");
        $stmt->execute([$id]);
        $order = $stmt->fetch();

        if (!$order) { http_response_code(404); require 'app/views/404.php'; return; }

        // Only admin or order owner can view
        if ($_SESSION['user_role'] !== 'admin' && $order['user_id'] != $_SESSION['user_id']) {
            http_response_code(403); require 'app/views/403.php'; return;
        }

        $itemStmt = $this->db->prepare(
            "SELECT oi.*, p.name AS product_name, p.image_url FROM order_items oi JOIN products p ON oi.product_id=p.product_id WHERE oi.order_id=?"
        );
        $itemStmt->execute([$id]);
        $items = $itemStmt->fetchAll();

        require 'app/views/orders/show.php';
    }

    // CREATE form — select product & quantity
    public function create(): void {
        AuthController::requireLogin();
        $productId = filter_input(INPUT_GET, 'product_id', FILTER_VALIDATE_INT);
        $product = null;
        if ($productId) {
            $stmt = $this->db->prepare("SELECT * FROM products WHERE product_id = ?");
            $stmt->execute([$productId]);
            $product = $stmt->fetch();
        }
        require 'app/views/orders/create.php';
    }

    // STORE — place a new order
    public function store(): void {
        AuthController::requireLogin();
        $this->validateCsrf();

        $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
        $quantity  = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

        $errors = [];
        if (!$productId) $errors[] = 'Invalid product selected.';
        if (!$quantity || $quantity < 1) $errors[] = 'Quantity must be at least 1.';

        // Fetch product and check stock
        $stmt = $this->db->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();

        if (!$product) {
            $errors[] = 'Product not found.';
        } elseif ($product['stock_qty'] < $quantity) {
            $errors[] = "Insufficient stock. Only {$product['stock_qty']} units available.";
        }

        if ($errors) {
            $_SESSION['errors'] = $errors;
            header("Location: /shopease/orders/create?product_id=$productId");
            exit;
        }

        $total = $product['price'] * $quantity;

        $this->db->beginTransaction();
        try {
            // Create order
            $stmt = $this->db->prepare(
                "INSERT INTO orders (user_id, status, total_price) VALUES (?, 'pending', ?)"
            );
            $stmt->execute([$_SESSION['user_id'], $total]);
            $orderId = $this->db->lastInsertId();

            // Create order item
            $stmt = $this->db->prepare(
                "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?,?,?,?)"
            );
            $stmt->execute([$orderId, $productId, $quantity, $product['price']]);

            // Decrement stock
            $stmt = $this->db->prepare("UPDATE products SET stock_qty = stock_qty - ? WHERE product_id = ?");
            $stmt->execute([$quantity, $productId]);

            $this->db->commit();
            $this->log('create_order', 'orders', $orderId, "Order placed for {$product['name']} x$quantity");

            $_SESSION['success'] = "Order placed successfully! Order #$orderId";
            header("Location: /shopease/orders/$orderId");
            exit;

        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Order creation failed: " . $e->getMessage());
            $_SESSION['errors'] = ['Failed to place order. Please try again.'];
            header("Location: /shopease/orders/create?product_id=$productId");
            exit;
        }
    }

    // CANCEL order (customer — only if pending)
    public function cancel(int $id): void {
        AuthController::requireLogin();
        $this->validateCsrf();

        $stmt = $this->db->prepare("SELECT * FROM orders WHERE order_id = ?");
        $stmt->execute([$id]);
        $order = $stmt->fetch();

        if (!$order || ($order['user_id'] != $_SESSION['user_id'] && $_SESSION['user_role'] !== 'admin')) {
            http_response_code(403); require 'app/views/403.php'; return;
        }
        if ($order['status'] !== 'pending') {
            $_SESSION['errors'] = ['Only pending orders can be cancelled.'];
            header("Location: /shopease/orders/$id");
            exit;
        }

        // Restore stock
        $items = $this->db->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $items->execute([$id]);
        foreach ($items->fetchAll() as $item) {
            $this->db->prepare("UPDATE products SET stock_qty = stock_qty + ? WHERE product_id = ?")
                ->execute([$item['quantity'], $item['product_id']]);
        }

        $this->db->prepare("UPDATE orders SET status='cancelled', updated_by=?, updated_at=NOW() WHERE order_id=?")
            ->execute([$_SESSION['user_id'], $id]);

        $this->log('cancel_order', 'orders', $id, "Order #$id cancelled");
        $_SESSION['success'] = "Order #$id has been cancelled.";
        header('Location: /shopease/orders');
        exit;
    }

    // UPDATE STATUS — admin only
    public function updateStatus(int $id): void {
        AuthController::requireAdmin();
        $this->validateCsrf();

        $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_SPECIAL_CHARS);
        $valid  = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];

        if (!in_array($status, $valid)) {
            $_SESSION['errors'] = ['Invalid status selected.'];
            header("Location: /shopease/orders/$id");
            exit;
        }

        $this->db->prepare("UPDATE orders SET status=?, updated_by=?, updated_at=NOW() WHERE order_id=?")
            ->execute([$status, $_SESSION['user_id'], $id]);

        $this->log('update_order_status', 'orders', $id, "Status changed to: $status");
        $_SESSION['success'] = "Order #$id status updated to '$status'.";
        header("Location: /shopease/orders/$id");
        exit;
    }

    // ── Helpers ──────────────────────────────────────────────
    private function validateCsrf(): void {
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
            http_response_code(403); die('Invalid CSRF token.');
        }
    }

    private function log(string $action, string $entity, int $entityId, string $details): void {
        $stmt = $this->db->prepare(
            "INSERT INTO activity_log (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)"
        );
        $stmt->execute([$_SESSION['user_id'] ?? null, $action, $entity, $entityId, $details]);
    }
}
