<?php
// app/controllers/ProductController.php
// CRUD for Products + Search + Pagination

class ProductController {

    private PDO $db;
    private int $perPage = 6;

    public function __construct() {
        $this->db = getDB();
    }

    // LIST — with search, filter by category, pagination
    public function index(): void {
        $search   = filter_input(INPUT_GET, 'q', FILTER_SANITIZE_SPECIAL_CHARS) ?? '';
        $category = filter_input(INPUT_GET, 'category', FILTER_SANITIZE_SPECIAL_CHARS) ?? '';
        $page     = max(1, (int)($_GET['page'] ?? 1));
        $offset   = ($page - 1) * $this->perPage;

        $where  = "WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $where   .= " AND (name LIKE ? OR description LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        if (!empty($category)) {
            $where   .= " AND category = ?";
            $params[] = $category;
        }

        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM products $where");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();
        $pages = (int)ceil($total / $this->perPage);

        $params[] = $this->perPage;
        $params[] = $offset;
        $stmt = $this->db->prepare(
            "SELECT * FROM products $where ORDER BY created_at DESC LIMIT ? OFFSET ?"
        );
        $stmt->execute($params);
        $products = $stmt->fetchAll();

        // Get categories for filter dropdown
        $catStmt    = $this->db->query("SELECT DISTINCT category FROM products ORDER BY category");
        $categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);

        require 'app/views/products/index.php';
    }

    // SHOW single product
    public function show(int $id): void {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        if (!$product) { $this->notFound(); return; }
        require 'app/views/products/show.php';
    }

    // CREATE form
    public function create(): void {
        AuthController::requireAdmin();
        require 'app/views/products/create.php';
    }

    // STORE new product
    public function store(): void {
        AuthController::requireAdmin();
        $this->validateCsrf();

        $data   = $this->sanitizeProductInput();
        $errors = $this->validateProductData($data);

        if ($errors) {
            $_SESSION['errors'] = $errors;
            header('Location: /shopease/products/create');
            exit;
        }

        $stmt = $this->db->prepare(
            "INSERT INTO products (name, description, price, stock_qty, category, image_url, created_by)
             VALUES (?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $data['name'], $data['description'], $data['price'],
            $data['stock_qty'], $data['category'], $data['image_url'],
            $_SESSION['user_id']
        ]);
        $newId = $this->db->lastInsertId();
        $this->log('create_product', 'products', $newId, "Created product: {$data['name']}");

        $_SESSION['success'] = "Product '{$data['name']}' created successfully.";
        header('Location: /shopease/products');
        exit;
    }

    // EDIT form
    public function edit(int $id): void {
        AuthController::requireAdmin();
        $stmt = $this->db->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        if (!$product) { $this->notFound(); return; }
        require 'app/views/products/edit.php';
    }

    // UPDATE product
    public function update(int $id): void {
        AuthController::requireAdmin();
        $this->validateCsrf();

        $data   = $this->sanitizeProductInput();
        $errors = $this->validateProductData($data);

        if ($errors) {
            $_SESSION['errors'] = $errors;
            header("Location: /shopease/products/$id/edit");
            exit;
        }

        $stmt = $this->db->prepare(
            "UPDATE products SET name=?, description=?, price=?, stock_qty=?, category=?, image_url=?, updated_at=NOW()
             WHERE product_id=?"
        );
        $stmt->execute([
            $data['name'], $data['description'], $data['price'],
            $data['stock_qty'], $data['category'], $data['image_url'], $id
        ]);
        $this->log('update_product', 'products', $id, "Updated product: {$data['name']}");

        $_SESSION['success'] = "Product updated successfully.";
        header('Location: /shopease/products');
        exit;
    }

    // DELETE product
    public function delete(int $id): void {
        AuthController::requireAdmin();
        $this->validateCsrf();

        $stmt = $this->db->prepare("SELECT name FROM products WHERE product_id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        if (!$product) { $this->notFound(); return; }

        $this->db->prepare("DELETE FROM products WHERE product_id = ?")->execute([$id]);
        $this->log('delete_product', 'products', $id, "Deleted product: {$product['name']}");

        $_SESSION['success'] = "Product deleted.";
        header('Location: /shopease/products');
        exit;
    }

    // ── Helpers ──────────────────────────────────────────────

    private function sanitizeProductInput(): array {
        return [
            'name'        => filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS),
            'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS),
            'price'       => filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT),
            'stock_qty'   => filter_input(INPUT_POST, 'stock_qty', FILTER_VALIDATE_INT),
            'category'    => filter_input(INPUT_POST, 'category', FILTER_SANITIZE_SPECIAL_CHARS),
            'image_url'   => filter_input(INPUT_POST, 'image_url', FILTER_SANITIZE_URL) ?: 'placeholder.png',
        ];
    }

    private function validateProductData(array $data): array {
        $errors = [];
        if (empty($data['name']) || strlen($data['name']) < 2) $errors[] = 'Product name is required (min 2 chars).';
        if ($data['price'] === false || $data['price'] <= 0)   $errors[] = 'Price must be a positive number.';
        if ($data['stock_qty'] === false || $data['stock_qty'] < 0) $errors[] = 'Stock quantity must be 0 or more.';
        if (empty($data['category'])) $errors[] = 'Category is required.';
        return $errors;
    }

    private function validateCsrf(): void {
        $token = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            http_response_code(403); die('Invalid CSRF token.');
        }
    }

    private function log(string $action, string $entity, int $entityId, string $details): void {
        $stmt = $this->db->prepare(
            "INSERT INTO activity_log (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)"
        );
        $stmt->execute([$_SESSION['user_id'] ?? null, $action, $entity, $entityId, $details]);
    }

    private function notFound(): void {
        http_response_code(404); require 'app/views/404.php';
    }
}
