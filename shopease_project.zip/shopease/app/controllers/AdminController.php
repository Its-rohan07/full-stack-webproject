<?php
// app/controllers/AdminController.php
// Admin dashboard, user management, activity logs, FAQ management

class AdminController {

    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    // DASHBOARD — summary stats
    public function dashboard(): void {
        AuthController::requireAdmin();

        $stats = [
            'total_products' => $this->db->query("SELECT COUNT(*) FROM products")->fetchColumn(),
            'total_orders'   => $this->db->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
            'total_users'    => $this->db->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn(),
            'pending_orders' => $this->db->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn(),
            'revenue'        => $this->db->query("SELECT COALESCE(SUM(total_price),0) FROM orders WHERE status != 'cancelled'")->fetchColumn(),
        ];

        $recentOrders = $this->db->query(
            "SELECT o.*, u.name AS customer_name FROM orders o JOIN users u ON o.user_id=u.user_id ORDER BY o.created_at DESC LIMIT 5"
        )->fetchAll();

        require 'app/views/admin/dashboard.php';
    }

    // USER LIST
    public function users(): void {
        AuthController::requireAdmin();
        $users = $this->db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
        require 'app/views/admin/users.php';
    }

    // ACTIVITY LOGS
    public function logs(): void {
        AuthController::requireAdmin();
        $logs = $this->db->query(
            "SELECT al.*, u.name AS user_name FROM activity_log al LEFT JOIN users u ON al.user_id=u.user_id ORDER BY al.timestamp DESC LIMIT 100"
        )->fetchAll();
        require 'app/views/admin/logs.php';
    }

    // FAQ MANAGEMENT
    public function faq(): void {
        AuthController::requireAdmin();
        $faqs = $this->db->query("SELECT * FROM faq_kb ORDER BY category, faq_id")->fetchAll();
        require 'app/views/admin/faq.php';
    }

    public function storeFaq(): void {
        AuthController::requireAdmin();
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
            http_response_code(403); die('Invalid CSRF token.');
        }

        $question = filter_input(INPUT_POST, 'question', FILTER_SANITIZE_SPECIAL_CHARS);
        $answer   = filter_input(INPUT_POST, 'answer', FILTER_SANITIZE_SPECIAL_CHARS);
        $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_SPECIAL_CHARS);
        $keywords = filter_input(INPUT_POST, 'keywords', FILTER_SANITIZE_SPECIAL_CHARS);

        if (empty($question) || empty($answer)) {
            $_SESSION['errors'] = ['Question and answer are required.'];
            header('Location: /shopease/admin/faq');
            exit;
        }

        $this->db->prepare(
            "INSERT INTO faq_kb (question, answer, category, keywords) VALUES (?,?,?,?)"
        )->execute([$question, $answer, $category, $keywords]);

        $_SESSION['success'] = 'FAQ entry added successfully.';
        header('Location: /shopease/admin/faq');
        exit;
    }

    public function deleteFaq(int $id): void {
        AuthController::requireAdmin();
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
            http_response_code(403); die('Invalid CSRF token.');
        }
        $this->db->prepare("DELETE FROM faq_kb WHERE faq_id = ?")->execute([$id]);
        $_SESSION['success'] = 'FAQ entry deleted.';
        header('Location: /shopease/admin/faq');
        exit;
    }
}
