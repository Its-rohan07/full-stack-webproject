</main>

<footer class="bg-dark text-light py-4 mt-5">
    <div class="container text-center">
        <p class="mb-1">&copy; <?= date('Y') ?> ShopEase &mdash; ICT203 Assessment 3</p>
        <small class="text-muted">Built with PHP + MySQL + Bootstrap 5</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/shopease/public/js/validation.js"></script>
</body>
</html>
