<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'ShopEase') ?> | ShopEase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="/shopease/public/css/styles.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/shopease/home">
            <i class="bi bi-shop me-2"></i>ShopEase
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/shopease/products"><i class="bi bi-grid me-1"></i>Catalogue</a>
                </li>
                <?php if (!empty($_SESSION['user_id'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/shopease/orders"><i class="bi bi-bag me-1"></i>My Orders</a>
                </li>
                <?php if ($_SESSION['user_role'] === 'admin'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-speedometer2 me-1"></i>Admin
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="/shopease/admin"><i class="bi bi-grid me-2"></i>Dashboard</a></li>
                        <li><a class="dropdown-item" href="/shopease/products/create"><i class="bi bi-plus-circle me-2"></i>Add Product</a></li>
                        <li><a class="dropdown-item" href="/shopease/admin/users"><i class="bi bi-people me-2"></i>Users</a></li>
                        <li><a class="dropdown-item" href="/shopease/admin/faq"><i class="bi bi-question-circle me-2"></i>Manage FAQ</a></li>
                        <li><a class="dropdown-item" href="/shopease/admin/logs"><i class="bi bi-journal-text me-2"></i>Activity Logs</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="/shopease/help"><i class="bi bi-robot me-1"></i>Help</a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <?php if (!empty($_SESSION['user_id'])): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($_SESSION['user_name']) ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text text-muted small"><?= ucfirst($_SESSION['user_role']) ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="/shopease/logout" method="POST">
                                <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-2"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </li>
                <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="/shopease/login">Login</a></li>
                <li class="nav-item"><a class="btn btn-primary btn-sm ms-2 nav-link" href="/shopease/register">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="container py-4">

<?php
// Flash messages
if (!empty($_SESSION['success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">'
        . htmlspecialchars($_SESSION['success'])
        . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['success']);
}
if (!empty($_SESSION['errors'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"><ul class="mb-0">';
    foreach ($_SESSION['errors'] as $e) {
        echo '<li>' . htmlspecialchars($e) . '</li>';
    }
    echo '</ul><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['errors']);
}
?>
