<?php $pageTitle = 'Login'; require 'app/views/layout/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h3 class="card-title mb-4 text-center"><i class="bi bi-lock me-2"></i>Login</h3>
                <form action="/shopease/login" method="POST" id="loginForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">

                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="email"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        <div class="invalid-feedback">Please enter a valid email.</div>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required minlength="1">
                        <div class="invalid-feedback">Password is required.</div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
                <hr>
                <p class="text-center mb-0">Don't have an account? <a href="/shopease/register">Register</a></p>
            </div>
        </div>
        <p class="text-muted text-center mt-3 small">
            Demo: admin@shopease.com / Admin@123 &nbsp;|&nbsp; user@shopease.com / User@123
        </p>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
