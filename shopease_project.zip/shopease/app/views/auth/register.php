<?php $pageTitle = 'Register'; require 'app/views/layout/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h3 class="card-title mb-4 text-center"><i class="bi bi-person-plus me-2"></i>Create Account</h3>
                <form action="/shopease/register" method="POST" id="registerForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">

                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name"
                               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required minlength="2">
                        <div class="invalid-feedback">Name must be at least 2 characters.</div>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="email"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        <div class="invalid-feedback">Please enter a valid email.</div>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password"
                               required minlength="8">
                        <div class="invalid-feedback">Password must be at least 8 characters.</div>
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password"
                               name="confirm_password" required>
                        <div class="invalid-feedback">Passwords must match.</div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Create Account</button>
                </form>
                <hr>
                <p class="text-center mb-0">Already have an account? <a href="/shopease/login">Login</a></p>
            </div>
        </div>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
