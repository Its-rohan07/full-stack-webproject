<?php $pageTitle = 'Admin Dashboard'; require 'app/views/layout/header.php'; ?>

<h2 class="mb-4"><i class="bi bi-speedometer2 me-2"></i>Admin Dashboard</h2>

<!-- Stats Cards -->
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <div class="fs-2 fw-bold"><?= $stats['total_products'] ?></div>
                    <div class="small">Total Products</div>
                </div>
                <i class="bi bi-grid fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <div class="fs-2 fw-bold"><?= $stats['total_orders'] ?></div>
                    <div class="small">Total Orders</div>
                </div>
                <i class="bi bi-bag fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <div class="fs-2 fw-bold"><?= $stats['pending_orders'] ?></div>
                    <div class="small">Pending Orders</div>
                </div>
                <i class="bi bi-hourglass-split fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info shadow-sm border-0">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <div class="fs-2 fw-bold">$<?= number_format($stats['revenue'], 0) ?></div>
                    <div class="small">Total Revenue</div>
                </div>
                <i class="bi bi-currency-dollar fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row g-3 mb-4">
    <div class="col-auto"><a href="/shopease/products/create" class="btn btn-success"><i class="bi bi-plus-circle me-1"></i>Add Product</a></div>
    <div class="col-auto"><a href="/shopease/orders" class="btn btn-primary"><i class="bi bi-bag me-1"></i>Manage Orders</a></div>
    <div class="col-auto"><a href="/shopease/admin/users" class="btn btn-secondary"><i class="bi bi-people me-1"></i>View Users</a></div>
    <div class="col-auto"><a href="/shopease/admin/faq" class="btn btn-info"><i class="bi bi-question-circle me-1"></i>Manage FAQ</a></div>
    <div class="col-auto"><a href="/shopease/admin/logs" class="btn btn-outline-secondary"><i class="bi bi-journal-text me-1"></i>Activity Logs</a></div>
</div>

<!-- Recent Orders -->
<h5 class="mb-3">Recent Orders</h5>
<div class="table-responsive">
    <table class="table table-hover">
        <thead class="table-dark">
            <tr><th>#</th><th>Customer</th><th>Status</th><th>Total</th><th>Date</th><th></th></tr>
        </thead>
        <tbody>
            <?php foreach ($recentOrders as $order): ?>
            <tr>
                <td>#<?= $order['order_id'] ?></td>
                <td><?= htmlspecialchars($order['customer_name']) ?></td>
                <td>
                    <?php $b = ['pending'=>'warning','confirmed'=>'info','shipped'=>'primary','delivered'=>'success','cancelled'=>'danger'][$order['status']] ?? 'secondary'; ?>
                    <span class="badge bg-<?= $b ?>"><?= ucfirst($order['status']) ?></span>
                </td>
                <td>$<?= number_format($order['total_price'], 2) ?></td>
                <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                <td><a href="/shopease/orders/<?= $order['order_id'] ?>" class="btn btn-sm btn-outline-primary">View</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require 'app/views/layout/footer.php'; ?>
