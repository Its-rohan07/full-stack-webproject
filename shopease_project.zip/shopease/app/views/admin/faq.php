<?php $pageTitle = 'Manage FAQ'; require 'app/views/layout/header.php'; ?>

<h2 class="mb-4"><i class="bi bi-question-circle me-2"></i>Manage FAQ Knowledge Base</h2>
<p class="text-muted">These entries power the AI Help Assistant. All answers are human-curated and reviewed by admins before being made available to users.</p>

<!-- Add FAQ Form -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-success text-white"><strong>Add New FAQ Entry</strong></div>
    <div class="card-body">
        <form action="/shopease/admin/faq" method="POST" id="faqForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Question <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="question" required placeholder="e.g. How do I track my order?">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Category</label>
                    <input type="text" class="form-control" name="category" placeholder="e.g. Orders, Returns">
                </div>
                <div class="col-12">
                    <label class="form-label">Answer <span class="text-danger">*</span></label>
                    <textarea class="form-control" name="answer" rows="3" required placeholder="The full answer text shown to customers."></textarea>
                </div>
                <div class="col-12">
                    <label class="form-label">Keywords <small class="text-muted">(space-separated, helps matching)</small></label>
                    <input type="text" class="form-control" name="keywords" placeholder="e.g. track order status shipping">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-success"><i class="bi bi-plus-lg me-1"></i>Add Entry</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Existing FAQs -->
<h5 class="mb-3">Current Entries (<?= count($faqs) ?>)</h5>
<?php
$grouped = [];
foreach ($faqs as $faq) { $grouped[$faq['category'] ?? 'General'][] = $faq; }
?>
<?php foreach ($grouped as $category => $entries): ?>
<h6 class="text-uppercase text-muted small mt-4"><?= htmlspecialchars($category) ?></h6>
<div class="list-group mb-3">
    <?php foreach ($entries as $faq): ?>
    <div class="list-group-item">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <strong><?= htmlspecialchars($faq['question']) ?></strong>
                <p class="mb-1 small text-muted"><?= htmlspecialchars($faq['answer']) ?></p>
                <?php if ($faq['keywords']): ?>
                <small class="text-info"><i class="bi bi-tags me-1"></i><?= htmlspecialchars($faq['keywords']) ?></small>
                <?php endif; ?>
            </div>
            <form action="/shopease/admin/faq/<?= $faq['faq_id'] ?>/delete" method="POST"
                  onsubmit="return confirm('Delete this FAQ entry?')" class="ms-3">
                <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endforeach; ?>

<?php require 'app/views/layout/footer.php'; ?>
