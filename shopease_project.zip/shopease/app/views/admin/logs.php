<?php $pageTitle = 'Activity Logs'; require 'app/views/layout/header.php'; ?>

<h2 class="mb-4"><i class="bi bi-journal-text me-2"></i>Activity Logs <small class="fs-6 text-muted">(Last 100 events)</small></h2>

<div class="table-responsive">
    <table class="table table-sm table-hover">
        <thead class="table-dark">
            <tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th></tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
            <tr>
                <td class="text-nowrap small"><?= date('d M H:i', strtotime($log['timestamp'])) ?></td>
                <td><?= htmlspecialchars($log['user_name'] ?? 'Guest') ?></td>
                <td><code><?= htmlspecialchars($log['action']) ?></code></td>
                <td><?= htmlspecialchars($log['entity'] ?? '') ?> <?= $log['entity_id'] ? "#" . $log['entity_id'] : '' ?></td>
                <td class="small text-muted"><?= htmlspecialchars($log['details'] ?? '') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require 'app/views/layout/footer.php'; ?>
