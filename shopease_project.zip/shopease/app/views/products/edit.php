<?php $pageTitle = 'Edit Product'; require 'app/views/layout/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-7">
        <h2 class="mb-4"><i class="bi bi-pencil-square me-2"></i>Edit Product</h2>
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form action="/shopease/products/<?= $product['product_id'] ?>/edit" method="POST" id="productForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">

                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name"
                               value="<?= htmlspecialchars($product['name']) ?>" required minlength="2">
                        <div class="invalid-feedback">Product name is required.</div>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($product['description']) ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="price" class="form-label">Price ($) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="price" name="price" step="0.01" min="0.01"
                                   value="<?= htmlspecialchars($product['price']) ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="stock_qty" class="form-label">Stock Quantity <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="stock_qty" name="stock_qty" min="0"
                                   value="<?= htmlspecialchars($product['stock_qty']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="category" class="form-label">Category <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="category" name="category"
                               value="<?= htmlspecialchars($product['category']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="image_url" class="form-label">Image Filename</label>
                        <input type="text" class="form-control" id="image_url" name="image_url"
                               value="<?= htmlspecialchars($product['image_url']) ?>">
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-warning"><i class="bi bi-save me-1"></i>Update Product</button>
                        <a href="/shopease/products" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
