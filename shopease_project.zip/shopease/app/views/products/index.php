<?php $pageTitle = 'Catalogue'; require 'app/views/layout/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-grid me-2"></i>Product Catalogue</h2>
    <?php if (!empty($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
    <a href="/shopease/products/create" class="btn btn-success">
        <i class="bi bi-plus-lg me-1"></i>Add Product
    </a>
    <?php endif; ?>
</div>

<!-- Search & Filter -->
<form method="GET" action="/shopease/products" class="row g-2 mb-4" id="searchForm">
    <div class="col-md-6">
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-search"></i></span>
            <input type="text" class="form-control" name="q" placeholder="Search products..."
                   value="<?= htmlspecialchars($search ?? '') ?>">
        </div>
    </div>
    <div class="col-md-4">
        <select class="form-select" name="category">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?= htmlspecialchars($cat) ?>" <?= ($category ?? '') === $cat ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat) ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-primary w-100">Filter</button>
    </div>
</form>

<!-- Products Grid -->
<?php if (empty($products)): ?>
<div class="alert alert-info">No products found. Try a different search.</div>
<?php else: ?>
<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">
    <?php foreach ($products as $product): ?>
    <div class="col">
        <div class="card h-100 shadow-sm">
            <img src="/shopease/public/img/<?= htmlspecialchars($product['image_url']) ?>"
                 class="card-img-top product-img"
                 alt="<?= htmlspecialchars($product['name']) ?>"
                 onerror="this.src='/shopease/public/img/placeholder.png'">
            <div class="card-body">
                <span class="badge bg-secondary mb-2"><?= htmlspecialchars($product['category']) ?></span>
                <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                <p class="card-text text-muted small">
                    <?= htmlspecialchars(substr($product['description'], 0, 80)) ?>...
                </p>
            </div>
            <div class="card-footer d-flex justify-content-between align-items-center">
                <span class="fs-5 fw-bold text-primary">$<?= number_format($product['price'], 2) ?></span>
                <div>
                    <?php if ($product['stock_qty'] > 0): ?>
                        <span class="badge bg-success me-1"><?= $product['stock_qty'] ?> in stock</span>
                        <?php if (!empty($_SESSION['user_id'])): ?>
                        <a href="/shopease/orders/create?product_id=<?= $product['product_id'] ?>"
                           class="btn btn-primary btn-sm">
                            <i class="bi bi-cart-plus"></i> Order
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="badge bg-danger">Out of stock</span>
                    <?php endif; ?>
                    <?php if (!empty($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                    <a href="/shopease/products/<?= $product['product_id'] ?>/edit" class="btn btn-warning btn-sm ms-1">
                        <i class="bi bi-pencil"></i>
                    </a>
                    <form action="/shopease/products/<?= $product['product_id'] ?>/delete" method="POST" class="d-inline"
                          onsubmit="return confirm('Delete this product?')">
                        <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Pagination -->
<?php if ($pages > 1): ?>
<nav>
    <ul class="pagination justify-content-center">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
        <li class="page-item <?= $page === $i ? 'active' : '' ?>">
            <a class="page-link" href="?q=<?= urlencode($search ?? '') ?>&category=<?= urlencode($category ?? '') ?>&page=<?= $i ?>">
                <?= $i ?>
            </a>
        </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
<?php endif; ?>

<?php if (empty($_SESSION['user_id'])): ?>
<div class="alert alert-info mt-3">
    <i class="bi bi-info-circle me-2"></i>
    <a href="/shopease/login">Login</a> or <a href="/shopease/register">register</a> to place orders.
</div>
<?php endif; ?>

<?php require 'app/views/layout/footer.php'; ?>
