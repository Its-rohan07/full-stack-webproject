<?php $pageTitle = 'Add Product'; require 'app/views/layout/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-7">
        <h2 class="mb-4"><i class="bi bi-plus-circle me-2"></i>Add New Product</h2>
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form action="/shopease/products/create" method="POST" id="productForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">

                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name"
                               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required minlength="2">
                        <div class="invalid-feedback">Product name is required (min 2 chars).</div>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="price" class="form-label">Price ($) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="price" name="price" step="0.01" min="0.01"
                                   value="<?= htmlspecialchars($_POST['price'] ?? '') ?>" required>
                            <div class="invalid-feedback">Please enter a valid price.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="stock_qty" class="form-label">Stock Quantity <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="stock_qty" name="stock_qty" min="0"
                                   value="<?= htmlspecialchars($_POST['stock_qty'] ?? '0') ?>" required>
                            <div class="invalid-feedback">Stock quantity must be 0 or more.</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="category" class="form-label">Category <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="category" name="category"
                               placeholder="e.g. Electronics, Footwear, Kitchen"
                               value="<?= htmlspecialchars($_POST['category'] ?? '') ?>" required>
                        <div class="invalid-feedback">Category is required.</div>
                    </div>

                    <div class="mb-3">
                        <label for="image_url" class="form-label">Image Filename</label>
                        <input type="text" class="form-control" id="image_url" name="image_url"
                               placeholder="e.g. headphones.jpg (place in /public/img/)"
                               value="<?= htmlspecialchars($_POST['image_url'] ?? '') ?>">
                        <div class="form-text">Upload image to /public/img/ and enter the filename.</div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-success"><i class="bi bi-check-lg me-1"></i>Save Product</button>
                        <a href="/shopease/products" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
