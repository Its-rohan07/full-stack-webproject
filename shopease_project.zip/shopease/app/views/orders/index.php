<?php $pageTitle = 'Orders'; require 'app/views/layout/header.php'; ?>

<h2 class="mb-4">
    <i class="bi bi-bag me-2"></i>
    <?= $_SESSION['user_role'] === 'admin' ? 'All Orders' : 'My Orders' ?>
</h2>

<?php if (empty($orders)): ?>
<div class="alert alert-info">
    No orders found. <a href="/shopease/products">Browse the catalogue</a> to place your first order.
</div>
<?php else: ?>
<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <?php if ($_SESSION['user_role'] === 'admin'): ?><th>Customer</th><?php endif; ?>
                <th>Status</th>
                <th>Total</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><strong>#<?= $order['order_id'] ?></strong></td>
                <?php if ($_SESSION['user_role'] === 'admin'): ?>
                <td><?= htmlspecialchars($order['customer_name']) ?></td>
                <?php endif; ?>
                <td>
                    <?php
                    $badges = [
                        'pending'   => 'warning',
                        'confirmed' => 'info',
                        'shipped'   => 'primary',
                        'delivered' => 'success',
                        'cancelled' => 'danger',
                    ];
                    $badge = $badges[$order['status']] ?? 'secondary';
                    ?>
                    <span class="badge bg-<?= $badge ?>"><?= ucfirst($order['status']) ?></span>
                </td>
                <td>$<?= number_format($order['total_price'], 2) ?></td>
                <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                <td>
                    <a href="/shopease/orders/<?= $order['order_id'] ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-eye"></i> View
                    </a>
                    <?php if ($order['status'] === 'pending'): ?>
                    <form action="/shopease/orders/<?= $order['order_id'] ?>/cancel" method="POST" class="d-inline"
                          onsubmit="return confirm('Cancel this order?')">
                        <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-x-circle"></i> Cancel
                        </button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php require 'app/views/layout/footer.php'; ?>
