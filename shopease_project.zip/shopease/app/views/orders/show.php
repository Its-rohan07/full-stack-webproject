<?php $pageTitle = "Order #{$order['order_id']}"; require 'app/views/layout/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="bi bi-receipt me-2"></i>Order #<?= $order['order_id'] ?></h2>
    <a href="/shopease/orders" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Back to Orders
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-light"><strong>Order Items</strong></div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td>$<?= number_format($item['unit_price'], 2) ?></td>
                            <td>$<?= number_format($item['unit_price'] * $item['quantity'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <td colspan="3" class="text-end fw-bold">Total</td>
                            <td class="fw-bold text-primary">$<?= number_format($order['total_price'], 2) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-header bg-light"><strong>Order Info</strong></div>
            <div class="card-body">
                <p class="mb-1"><strong>Status:</strong>
                    <?php
                    $badges = ['pending'=>'warning','confirmed'=>'info','shipped'=>'primary','delivered'=>'success','cancelled'=>'danger'];
                    $badge = $badges[$order['status']] ?? 'secondary';
                    ?>
                    <span class="badge bg-<?= $badge ?>"><?= ucfirst($order['status']) ?></span>
                </p>
                <?php if (isset($order['customer_name'])): ?>
                <p class="mb-1"><strong>Customer:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
                <?php endif; ?>
                <p class="mb-1"><strong>Placed:</strong> <?= date('d M Y H:i', strtotime($order['created_at'])) ?></p>
            </div>
        </div>

        <?php if ($order['status'] === 'pending'): ?>
        <form action="/shopease/orders/<?= $order['order_id'] ?>/cancel" method="POST"
              onsubmit="return confirm('Are you sure you want to cancel this order?')">
            <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
            <button type="submit" class="btn btn-danger w-100 mb-2">
                <i class="bi bi-x-circle me-1"></i>Cancel Order
            </button>
        </form>
        <?php endif; ?>

        <?php if ($_SESSION['user_role'] === 'admin'): ?>
        <div class="card shadow-sm border-0">
            <div class="card-header bg-warning bg-opacity-25"><strong>Update Status</strong></div>
            <div class="card-body">
                <form action="/shopease/orders/<?= $order['order_id'] ?>/status" method="POST">
                    <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
                    <select class="form-select mb-2" name="status">
                        <?php foreach (['pending','confirmed','shipped','delivered','cancelled'] as $s): ?>
                        <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>>
                            <?= ucfirst($s) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-warning w-100">
                        <i class="bi bi-arrow-repeat me-1"></i>Update Status
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
