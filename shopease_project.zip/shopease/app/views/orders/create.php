<?php $pageTitle = 'Place Order'; require 'app/views/layout/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <h2 class="mb-4"><i class="bi bi-cart-plus me-2"></i>Place Order</h2>

        <?php if (!$product): ?>
        <div class="alert alert-warning">Product not found. <a href="/shopease/products">Browse products</a>.</div>
        <?php else: ?>

        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body d-flex gap-3 align-items-center">
                <img src="/shopease/public/img/<?= htmlspecialchars($product['image_url']) ?>"
                     style="width:80px;height:80px;object-fit:cover;border-radius:8px;"
                     onerror="this.src='/shopease/public/img/placeholder.png'"
                     alt="<?= htmlspecialchars($product['name']) ?>">
                <div>
                    <h5 class="mb-1"><?= htmlspecialchars($product['name']) ?></h5>
                    <p class="text-muted mb-1 small"><?= htmlspecialchars($product['category']) ?></p>
                    <span class="fs-5 fw-bold text-primary">$<?= number_format($product['price'], 2) ?></span>
                    <span class="badge bg-success ms-2"><?= $product['stock_qty'] ?> in stock</span>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form action="/shopease/orders/create" method="POST" id="orderForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= AuthController::generateCsrf() ?>">
                    <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">

                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="quantity" name="quantity"
                               min="1" max="<?= $product['stock_qty'] ?>" value="1" required>
                        <div class="invalid-feedback">Quantity must be between 1 and <?= $product['stock_qty'] ?>.</div>
                    </div>

                    <div class="mb-3">
                        <p class="mb-1">Estimated Total: <strong class="text-primary" id="estimatedTotal">$<?= number_format($product['price'], 2) ?></strong></p>
                        <small class="text-muted">Price inclusive of GST. Shipping calculated at checkout.</small>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-bag-check me-1"></i>Confirm Order
                        </button>
                        <a href="/shopease/products" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>

        <script>
        const price = <?= $product['price'] ?>;
        document.getElementById('quantity').addEventListener('input', function() {
            const total = (parseFloat(this.value) || 0) * price;
            document.getElementById('estimatedTotal').textContent = '$' + total.toFixed(2);
        });
        </script>

        <?php endif; ?>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
