<?php $pageTitle = 'Help Assistant'; require 'app/views/layout/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <h2 class="mb-2"><i class="bi bi-robot me-2"></i>ShopEase Help Assistant</h2>
        <p class="text-muted mb-4">Ask a question and our AI assistant will search our knowledge base to help you.</p>

        <!-- AI Disclaimer -->
        <div class="alert alert-warning d-flex gap-2 align-items-start">
            <i class="bi bi-info-circle-fill mt-1"></i>
            <div>
                <strong>AI-Assisted Responses</strong> — Answers come from our curated FAQ knowledge base.
                For urgent matters, email <a href="mailto:support@shopease.com">support@shopease.com</a>.
                No personal data is processed by this assistant.
            </div>
        </div>

        <!-- Search Box -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body p-4">
                <div class="input-group">
                    <input type="text" class="form-control form-control-lg" id="helpQuery"
                           placeholder="e.g. How do I return an item?"
                           maxlength="200" autofocus>
                    <button class="btn btn-primary btn-lg" id="helpSearch">
                        <i class="bi bi-search me-1"></i>Ask
                    </button>
                </div>
                <div class="form-text mt-1">Try: "track my order", "return policy", "payment methods"</div>
            </div>
        </div>

        <!-- Results -->
        <div id="helpResults"></div>

        <!-- Suggested Topics -->
        <div id="suggestedTopics">
            <h6 class="text-muted mb-3">Popular topics:</h6>
            <div class="d-flex flex-wrap gap-2">
                <?php
                $topics = ['How do I place an order?', 'Can I cancel my order?', 'Return policy',
                           'Shipping time', 'Payment methods', 'Forgot password', 'Out of stock'];
                foreach ($topics as $topic): ?>
                <button class="btn btn-outline-secondary btn-sm topic-btn" data-query="<?= htmlspecialchars($topic) ?>">
                    <?= htmlspecialchars($topic) ?>
                </button>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const queryInput = document.getElementById('helpQuery');
    const searchBtn  = document.getElementById('helpSearch');
    const resultsDiv = document.getElementById('helpResults');
    const topicsDiv  = document.getElementById('suggestedTopics');

    function runSearch(query) {
        if (!query || query.trim().length < 2) return;

        resultsDiv.innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status"></div>
                <p class="mt-2 text-muted">Searching knowledge base...</p>
            </div>`;
        topicsDiv.style.display = 'none';

        fetch('/shopease/api/help', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query.trim() })
        })
        .then(r => r.json())
        .then(data => {
            if (data.error) {
                resultsDiv.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                return;
            }

            if (!data.results || data.results.length === 0) {
                resultsDiv.innerHTML = `
                    <div class="alert alert-info">
                        <i class="bi bi-search me-2"></i>
                        No results found for "<strong>${escapeHtml(query)}</strong>".
                        Try different keywords, or email <a href="mailto:support@shopease.com">support@shopease.com</a>.
                    </div>`;
                topicsDiv.style.display = 'block';
                return;
            }

            let html = `<p class="text-muted mb-3"><i class="bi bi-check-circle-fill text-success me-1"></i>Found ${data.results.length} result(s) for "<strong>${escapeHtml(query)}</strong>"</p>`;
            html += '<div class="accordion" id="faqAccordion">';
            data.results.forEach((item, i) => {
                const isFirst = i === 0 ? 'show' : '';
                html += `
                <div class="accordion-item border-0 shadow-sm mb-2">
                    <h2 class="accordion-header">
                        <button class="accordion-button ${i > 0 ? 'collapsed' : ''} fw-semibold" type="button"
                                data-bs-toggle="collapse" data-bs-target="#faqItem${i}">
                            <i class="bi bi-question-circle-fill text-primary me-2"></i>
                            ${escapeHtml(item.question)}
                        </button>
                    </h2>
                    <div id="faqItem${i}" class="accordion-collapse collapse ${isFirst}" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-muted">
                            ${escapeHtml(item.answer)}
                        </div>
                    </div>
                </div>`;
            });
            html += '</div>';

            // Disclaimer
            html += `
                <div class="alert alert-warning mt-3 small">
                    <i class="bi bi-robot me-1"></i>
                    <strong>AI Disclaimer:</strong> ${escapeHtml(data.disclaimer)}
                </div>
                <button class="btn btn-outline-secondary btn-sm mt-1" id="clearResults">
                    <i class="bi bi-arrow-left me-1"></i>Ask another question
                </button>`;

            resultsDiv.innerHTML = html;

            document.getElementById('clearResults').addEventListener('click', function() {
                resultsDiv.innerHTML = '';
                queryInput.value = '';
                topicsDiv.style.display = 'block';
                queryInput.focus();
            });
        })
        .catch(() => {
            resultsDiv.innerHTML = `<div class="alert alert-danger">Something went wrong. Please try again.</div>`;
            topicsDiv.style.display = 'block';
        });
    }

    searchBtn.addEventListener('click', () => runSearch(queryInput.value));
    queryInput.addEventListener('keydown', e => { if (e.key === 'Enter') runSearch(queryInput.value); });

    document.querySelectorAll('.topic-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            queryInput.value = this.dataset.query;
            runSearch(this.dataset.query);
        });
    });

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }
});
</script>

<?php require 'app/views/layout/footer.php'; ?>
