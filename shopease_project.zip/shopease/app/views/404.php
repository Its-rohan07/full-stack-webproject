<?php $pageTitle = '404 Not Found'; require 'app/views/layout/header.php'; ?>
<div class="text-center py-5">
    <h1 class="display-1 text-muted">404</h1>
    <h3>Page Not Found</h3>
    <p class="text-muted">The page you're looking for doesn't exist.</p>
    <a href="/shopease/home" class="btn btn-primary">Go Home</a>
</div>
<?php require 'app/views/layout/footer.php'; ?>
