<?php $pageTitle = '403 Forbidden'; require 'app/views/layout/header.php'; ?>
<div class="text-center py-5">
    <h1 class="display-1 text-danger">403</h1>
    <h3>Access Denied</h3>
    <p class="text-muted">You don't have permission to access this page.</p>
    <a href="/shopease/home" class="btn btn-primary">Go Home</a>
</div>
<?php require 'app/views/layout/footer.php'; ?>
