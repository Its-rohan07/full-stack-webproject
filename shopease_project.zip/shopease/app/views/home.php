<?php $pageTitle = 'Welcome'; require 'app/views/layout/header.php'; ?>

<div class="text-center py-5">
    <h1 class="display-4 fw-bold">Welcome to <span class="text-primary">ShopEase</span></h1>
    <p class="lead text-muted mb-4">Your one-stop shop for quality products, delivered to your door.</p>
    <a href="/shopease/products" class="btn btn-primary btn-lg me-2">
        <i class="bi bi-grid me-2"></i>Browse Catalogue
    </a>
    <?php if (empty($_SESSION['user_id'])): ?>
    <a href="/shopease/register" class="btn btn-outline-secondary btn-lg">
        <i class="bi bi-person-plus me-2"></i>Create Account
    </a>
    <?php endif; ?>
</div>

<div class="row g-4 mt-3 text-center">
    <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm p-4">
            <i class="bi bi-truck fs-1 text-primary mb-3"></i>
            <h5>Fast Delivery</h5>
            <p class="text-muted">Standard 3–5 days. Express 1–2 days.</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm p-4">
            <i class="bi bi-shield-check fs-1 text-success mb-3"></i>
            <h5>Secure Shopping</h5>
            <p class="text-muted">Your data is encrypted and protected.</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm p-4">
            <i class="bi bi-arrow-return-left fs-1 text-warning mb-3"></i>
            <h5>Easy Returns</h5>
            <p class="text-muted">30-day hassle-free return policy.</p>
        </div>
    </div>
</div>

<?php require 'app/views/layout/footer.php'; ?>
