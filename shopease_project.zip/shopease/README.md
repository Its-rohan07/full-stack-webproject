# ShopEase — Full-Stack Web Application
### ICT203 Web Application Development | Assessment 3

A secure, responsive, database-driven retail web application built with PHP 8+ + MySQL + Bootstrap 5.

---

## Setup Instructions (XAMPP)

1. **Import database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Create a database named `shopease`
   - Import `schema.sql` (includes tables + seed data)

2. **Configure database**
   - Open `/config/db.php`
   - Set `DB_USER` and `DB_PASS` to match your MySQL credentials

3. **Deploy files**
   - Copy the entire `/shopease` folder into your XAMPP `htdocs/` directory

4. **Enable Apache mod_rewrite**
   - In XAMPP → Apache → `httpd.conf`, ensure `mod_rewrite` is enabled
   - In the `<Directory "...htdocs">` block, set `AllowOverride All`

5. **Start XAMPP**
   - Start Apache and MySQL in the XAMPP control panel

6. **Visit the app**
   - `http://localhost/shopease`

---

## Demo Accounts

| Role     | Email                     | Password   |
|----------|---------------------------|------------|
| Admin    | admin@shopease.com        | Admin@123  |
| Customer | user@shopease.com         | User@123   |

> **Note:** The seed data uses placeholder password hashes. To set real passwords, run:
> ```
> php -r "echo password_hash('Admin@123', PASSWORD_DEFAULT);"
> ```
> Then update the `password_hash` field in the `users` table via phpMyAdmin.

---

## Technology Stack

- **Front-end:** HTML5, CSS3, JavaScript (ES6), Bootstrap 5.3
- **Back-end:** PHP 8+ (MVC-lite structure)
- **Database:** MySQL with PDO (prepared statements throughout)
- **Auth:** PHP sessions + `password_hash()` / `password_verify()`
- **Security:** CSRF tokens, input sanitisation, role-based access control

---

## Features

- User registration and login (Admin + Customer roles)
- Product catalogue with search, category filter, and pagination
- Full CRUD for Products (admin only)
- Order placement with stock management
- Order tracking and status updates (admin)
- Order cancellation (customer, pending only)
- Activity audit log
- AI Help Assistant (FAQ knowledge base, keyword matching)
- Admin FAQ management panel

---

## Project Structure

```
/shopease
├── index.php                  ← Front controller / router
├── .htaccess                  ← URL rewriting
├── schema.sql                 ← Full database schema + seed data
├── config/
│   └── db.php                 ← PDO connection
├── app/
│   ├── controllers/           ← AuthController, ProductController, OrderController, AdminController, AiController
│   ├── models/                ← (extend for model classes as needed)
│   └── views/
│       ├── layout/            ← header.php, footer.php
│       ├── auth/              ← login.php, register.php
│       ├── products/          ← index.php, create.php, edit.php
│       ├── orders/            ← index.php, show.php, create.php
│       ├── admin/             ← dashboard.php, users.php, logs.php, faq.php
│       └── help/              ← index.php (AI assistant)
├── public/
│   ├── css/styles.css
│   ├── js/validation.js
│   └── img/                   ← Place product images here
└── docs/                      ← All assessment documentation
```

---

## AI Use Statement

This project was developed with AI tools (Claude by Anthropic) used to assist with:
- Code scaffolding and boilerplate generation
- Documentation drafting

**All code was reviewed, understood, tested, and modified by team members before submission.** AI was used as an assistant, not a replacement for learning. All AI-generated code suggestions were verified against the assessment rubric, security requirements, and PHP/MySQL best practices.

The in-app AI Help Assistant uses a human-curated FAQ knowledge base. No personal user data is processed. All FAQ content is reviewed and controlled by the admin. The system logs all AI-assistant queries for auditability.

---

## Team

| Name | Role |
|------|------|
| [Member 1] | Team Lead / Scrum Master |
| [Member 2] | Front-End Lead |
| [Member 3] | Back-End Lead / Data & QA |

---

## Deployment

- **Local:** XAMPP as described above
- **Exported:** `htdocs/shopease.zip` + `shopease_db.sql`
